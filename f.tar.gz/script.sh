################# TASK-1 #######################
### Creating multiple files by WELCOME in it ###
for f in a.txt
do
    echo Welcome > "$f"
done

echo "10 files created with the word Welcome"
### USER INPUT #################################
$var1
$var2
echo "Please enter value for First variable"
read var1
echo "Please enter value for Second variable"
read var2
### COMPRESSING FILES ##########################
 if [ $var1 == $var2 ]
  then
   echo "Compressing files" 
   tar -cvf f.tar.gz .
   echo "Uploading files to GITHUB"
   git init
   git status
   git add f.tar.gz .
   git commit -m "first commit"
   git remote add origin https://github.com/Veni92/guvi-task-round1.git
   git pull --rebase master
   git push -f origin master
   git branch 
  else
   echo "Not matching"
  fi
